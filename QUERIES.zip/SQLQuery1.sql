
--select * from PaymentPassenger where BookingNo=6
--select * from PassengerDetails where BookingNo=6
--alter table CompletedPassenger add foreign key (BookingNo) references CompletedPP(BookingNo)
--alter table PaymentPassenger drop foreign key BookingNo
select * from PaymentPassenger
select * from PassengerDetails
select * from CompletedPP
select * from CompletedPassenger
